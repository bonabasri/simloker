
    <div class="row">
        <div class="col-lg-8">
            <h5 class="page-header"><small>Tambah Kategori Pekerjaan</small></h5>
    
            <div class="panel panel-default">
            <div class="panel-heading">Informasi Kategori Pekerjaan</div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-12">
   
                   
                <form class="" role="form" style="margin-top: 10px;" action="?p=kategorikerja.action" id="defaultForm" method="post" enctype="multipart/form-data">
                    
                    <div class="form-group">
                    <label> Nama Kategori Pekerjaan</label>
                        <input type="text" class="form-control" name="nama_kategori_kerja" placeholder="Nama Kategori Pekerjaan" required/>
                    </div>
                    
                    <div class="form-group">
                    <label></label>
                        <a class="btn btn-default" href="?p=kategorikerja.view">Batal</a>
                        <input type="submit" name="save" value="Simpan" class="btn btn-primary">
                    </div>                   
                </form>
            </div>
        </div>
    </div>
</div>
</div>
