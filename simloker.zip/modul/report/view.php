
    <div class="row">
        <div class="col-lg-8">
            <h3 class="page-header"><small>Report Lowongan</small></h3>
        
            <div class="panel panel-default">
            <div class="panel-heading">Report Lowongan</div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-12">
                    
 
                   
                <form class="form-horizantal" role="form" style="margin-top: 10px;" action="print.php?p=report.job" target="_blank" id="defaultForm" method="post" enctype="multipart/form-data">
                    
                    <div class="form-group col-md-4">
                    <label> Dari</label>
                        <input type="text" name="start" id="datepicker" class="form-control"/>
                    </div>
                    <div class="form-group col-md-4">
                    <label> Sampai</label>
                        <input type="text" name="end" id="datepicker1" class="form-control"/>
                    </div>
                    
                    <div class="form-group col-md-1">
                    <label></label>
                        <!-- <a class="btn btn-default" href="?p=job.view">Batal</a> -->
                        <button class="btn btn-primary" type="submit">Tampilkan</button>
                    </div>                   
                </form>
            </div>
        </div>
    </div>

            <div class="panel-heading">Report Perusahaan</div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-12">
                    
 
                   
                <form class="form-horizantal" role="form" style="margin-top: 10px;" action="print.php?p=report.employers" target="_blank" id="defaultForm" method="post" enctype="multipart/form-data">
                    
                    <div class="form-group col-md-4">
                    <label> Dari</label>
                        <input type="text" name="start" id="datepicker2" class="form-control"/>
                    </div>
                    <div class="form-group col-md-4">
                    <label> Sampai</label>
                        <input type="text" name="end" id="datepicker3" class="form-control"/>
                    </div>
                    
                    <div class="form-group col-md-1">
                    <label></label>
                        <!-- <a class="btn btn-default" href="?p=job.view">Batal</a> -->
                        <button class="btn btn-primary" type="submit">Tampilkan</button>
                    </div>                   
                </form>
            </div>
        </div>
    </div>

            <div class="panel-heading">Report Pelamar</div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-12">
                    
 
                   
                <form class="form-horizantal" role="form" style="margin-top: 10px;" action="print.php?p=report.aplicant" target="_blank" id="defaultForm" method="post" enctype="multipart/form-data">
                    
                    <div class="form-group col-md-4">
                    <label> Dari</label>
                        <input type="text" name="start" id="datepicker4" class="form-control"/>
                    </div>
                    <div class="form-group col-md-4">
                    <label> Sampai</label>
                        <input type="text" name="end" id="datepicker5" class="form-control"/>
                    </div>
                    
                    <div class="form-group col-md-1">
                    <label></label>
                        <!-- <a class="btn btn-default" href="?p=job.view">Batal</a> -->
                        <button class="btn btn-primary" type="submit">Tampilkan</button>
                    </div>                   
                </form>
            </div>
        </div>
    </div>
</div>
</div>
