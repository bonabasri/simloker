<div class="col-md-8">
	<div class="panel panel-default">
    	<div class="panel-body">
    <h1 class="page-header" >                
        <small> Pasang Lowongan</small>
    </h1>

Hi, Employers! Jika anda mencari talenta terbaik, daftarkan lowongan pekerjaan perusahaan anda di loker.com

Ikuti petunjuk berikut:
<ul>
	<li>
	    Silakan <a href="?p=login" class="btn btn-primary">Login</a> atau <a href="?p=register" class="btn btn-success">Register</a> terlebih dahulu untuk dapat mem-posting lowongan pekerjaan.
	</li>
	<li>
		Jika ini kali pertama anda mendaftar sebagai perusahaan, segera lengkapi profil perusahaan anda.</li>
	<li>
		1 lowongan hanya untuk 1 posisi. Jika ada lebih dari 1 posisi yang ditawarkan, pisahkan ke dalam beberapa JOB. Anda dapat mem-posting beberapa JOB.
	</li>
	<li>
		Agar Iklan anda aktif, maka lakukan Pembayaran Biaya Iklan Pembayaran melalui rekening :
		xxxxxxx-xxxxx-xx-xx
	</li>
	<li>
		Silahkan konfirmasi melalui lokercilacap.com.
		Sebutkan Jumlah biaya dan No Rekening
	</li>
	<li>
		Kami selanjutnya akan mengaktifkan iklan lowongan anda dan mempublish di website lokercilacap.com. Setelah aktif lowongan anda maka para pencari kerja dapat melakukan Apply Job online.
	</li>
	
	<!-- <li>
		Lowongan akan ditampilkan setelah anda membayar
	</li> -->
	<!-- <li>
		Lowongan akan ditampilkan maksimal 2×24 jam.
	</li> -->
</ul>
	<h1 class="page-header" >                
        <small> Paket Iklan Lokercilacap.com</small>
    </h1>
	<ul>
		
		<li>
			Paket iklan lowongan kerja di web Lokercilacap.com. <b>(Rp. 25.000,-) untuk 1 bulan tayang</b>
		</li>
		<li>
			Paket iklan lowongan kerja di web Lokercilacap.com. <b>(Rp. 15.000,-) untuk 2 minggu tayang</b>
		</li>
		<li>
			Pelamar dapat Apply Online dan upload CV.
		</li>
	</ul>
	</div>
</div>
</div>