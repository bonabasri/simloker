-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 23, 2017 at 10:26 PM
-- Server version: 10.0.31-MariaDB-0ubuntu0.16.04.2
-- PHP Version: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lokerclp_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_jenis_pekerjaan`
--

CREATE TABLE `tb_jenis_pekerjaan` (
  `id_jenis` int(5) NOT NULL,
  `nama_jenis_kerja` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_jenis_pekerjaan`
--

INSERT INTO `tb_jenis_pekerjaan` (`id_jenis`, `nama_jenis_kerja`) VALUES
(1, 'Freelance'),
(2, 'Fulltime'),
(3, 'Internship'),
(4, 'Parttime');

-- --------------------------------------------------------

--
-- Table structure for table `tb_kategori_pekerjaan`
--

CREATE TABLE `tb_kategori_pekerjaan` (
  `id_kategori_kerja` int(5) NOT NULL,
  `nama_kategori_kerja` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_kategori_pekerjaan`
--

INSERT INTO `tb_kategori_pekerjaan` (`id_kategori_kerja`, `nama_kategori_kerja`) VALUES
(1, 'Administrasi / Sekretaris'),
(2, 'Akuntansi dan Keuangan'),
(3, 'Otomotif'),
(4, 'Desain'),
(5, 'Driver'),
(6, 'Pramuniaga'),
(7, 'Sales'),
(8, 'Human Resources / Personalia'),
(9, 'Public Relation / Humas'),
(10, 'Sales Eksekutif'),
(11, 'Lainnya');

-- --------------------------------------------------------

--
-- Table structure for table `tb_kategori_pendidikan`
--

CREATE TABLE `tb_kategori_pendidikan` (
  `id_pendidikan` int(5) NOT NULL,
  `nama_pendidikan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_kategori_pendidikan`
--

INSERT INTO `tb_kategori_pendidikan` (`id_pendidikan`, `nama_pendidikan`) VALUES
(1, 'SD'),
(2, 'SMP'),
(3, 'SMA'),
(4, 'SMK'),
(5, 'SMA/SMK Sederajat'),
(6, 'D1'),
(7, 'D2'),
(8, 'D3'),
(9, 'D4'),
(10, 'S1'),
(11, 'D4/S1 Sederajat'),
(12, 'S2'),
(13, 'S3 Sederajat');

-- --------------------------------------------------------

--
-- Table structure for table `tb_kota`
--

CREATE TABLE `tb_kota` (
  `id_kota` smallint(2) NOT NULL,
  `id_provinsi` smallint(2) NOT NULL,
  `kota` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_kota`
--

INSERT INTO `tb_kota` (`id_kota`, `id_provinsi`, `kota`) VALUES
(1, 1, 'Banjarnegara'),
(2, 1, 'Brebes'),
(3, 1, 'Banyumas'),
(4, 1, 'Cilacap'),
(5, 1, 'Purwokerto'),
(6, 1, 'Purbalingga'),
(7, 1, 'Pemalang'),
(8, 1, 'Kebumen'),
(9, 2, 'Kota Jogja'),
(10, 2, 'Sleman'),
(11, 2, 'Bantul'),
(12, 2, 'Kulon Progo'),
(13, 2, 'Gunung Kidul');

-- --------------------------------------------------------

--
-- Table structure for table `tb_lamaran`
--

CREATE TABLE `tb_lamaran` (
  `id_lamaran` smallint(11) UNSIGNED NOT NULL,
  `id_lowongan` tinyint(5) NOT NULL,
  `user_id` char(15) NOT NULL,
  `file` varchar(50) NOT NULL,
  `files` varchar(50) NOT NULL,
  `message` tinytext NOT NULL,
  `status` tinyint(2) NOT NULL,
  `tgl_interview` date DEFAULT NULL,
  `tgl_lamar` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_lamaran`
--

INSERT INTO `tb_lamaran` (`id_lamaran`, `id_lowongan`, `user_id`, `file`, `files`, `message`, `status`, `tgl_interview`, `tgl_lamar`) VALUES
(2, 6, 'luqman', 'CV.doc', '', '', 2, NULL, '0000-00-00'),
(3, 5, 'puput', 'belajar-php-dengan-framework-code-igniter.pdf', '', 'besok', 1, NULL, '2017-07-08'),
(4, 7, 'puput', 'BAB1.docx', '', '', 0, NULL, '2017-07-08'),
(5, 2, 'puput', 'PROSEDUR_KP,_TA,_PTA_BARU_TI.docx', '', '', 1, NULL, '2017-07-08'),
(6, 7, 'luqman', 'format_proposal.doc', '', '', 0, NULL, '2017-07-11'),
(7, 8, 'riski', 'Naskah_Publikasi.pdf', '', 'besok datang interview ya siapkan perlengkapan', 2, '2017-07-13', '2017-07-12'),
(8, 2, 'riski', 'contoh01.doc', 'contoh01.doc', '', 0, NULL, '2017-07-20'),
(9, 9, 'muzan', 'CURICULUM_VITAE_baru.pdf', 'CURICULUM_VITAE_baru.pdf', 'silahkan bawa cv ijasah asli bersamaan proses interview', 1, '2017-07-25', '2017-07-24'),
(10, 14, 'muzan', 'CURICULUM_VITAE_baru.pdf', 'ijasah.pdf', '', 0, NULL, '2017-07-25'),
(11, 13, 'amal', 'CURICULUM_VITAE_baru.pdf', 'ijasah.pdf', '', 0, NULL, '2017-07-25');

-- --------------------------------------------------------

--
-- Table structure for table `tb_lowongan`
--

CREATE TABLE `tb_lowongan` (
  `id_lowongan` smallint(11) UNSIGNED NOT NULL,
  `user_id` char(15) NOT NULL,
  `id_kategori_pekerjaan` tinyint(5) NOT NULL,
  `id_jenis` tinyint(5) NOT NULL,
  `posisi` varchar(45) NOT NULL,
  `jk_require` varchar(15) NOT NULL,
  `usia` varchar(15) NOT NULL,
  `id_pendidikan` varchar(45) NOT NULL,
  `pengalaman` varchar(15) NOT NULL,
  `tgl_posting` date NOT NULL,
  `tgl_akhir` date NOT NULL,
  `img` varchar(150) NOT NULL,
  `deskripsi` text NOT NULL,
  `rekening` varchar(20) NOT NULL,
  `harga` double NOT NULL,
  `stat` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_lowongan`
--

INSERT INTO `tb_lowongan` (`id_lowongan`, `user_id`, `id_kategori_pekerjaan`, `id_jenis`, `posisi`, `jk_require`, `usia`, `id_pendidikan`, `pengalaman`, `tgl_posting`, `tgl_akhir`, `img`, `deskripsi`, `rekening`, `harga`, `stat`) VALUES
(1, 'topan', 7, 2, 'Sales Eksekutif', 'Wanita', '23 ta', '5', '1 tahun', '2017-06-13', '2017-06-20', '19930_1065042550196612_5610354022033314547_n.jpg', '<p><strong>JOB DESKRIPSION</strong></p>\r\n\r\n<p>Socmed Sales difokuskan untuk berjualan produk event dan pameran melalui media online.</p>\r\n\r\n<p><strong>BEBEFITS</strong></p>\r\n\r\n<ul>\r\n	<li>Sales akan mendapatkan network yang luas dan mendapatkan peluang penghasilan yang lebih besar.</li>\r\n	<li>Jenjang karir yang menjanjikan bagi yang berprestasi.</li>\r\n</ul>\r\n\r\n<p><strong>Job Requirements</strong></p>\r\n\r\n<ol>\r\n	<li>Wanita</li>\r\n	<li>Domisili Jogja</li>\r\n	<li>Socmed Addict</li>\r\n	<li>Pendidikan Min. D3</li>\r\n	<li>Berorientasi pada target</li>\r\n</ol>\r\n\r\n<p><strong>How To Apply</strong></p>\r\n\r\n<p>Email CV to EO.INCOMM@GMAIL.COM</p>\r\n\r\n<p>Contact to 0856.4307.9654 to confirm</p>\r\n\r\n<p><strong>More Information</strong></p>\r\n', '', 0, 0),
(2, 'topan', 5, 3, 'Driver Ojek', 'Pria', '30', '5', '1 tahun', '2017-06-26', '2017-07-23', '13015676_1260463240631270_6516178172027243326_n.jpg', '<p>Driver ojek punya sim c, baik, jujur disiplin</p>\r\n\r\n<p>send cv to topan@gmail.com</p>\r\n', '0641-08461-08-11', 25000, 2),
(3, 'topan', 2, 1, 'Akuntan', 'Pria & Wanita', '25 ta', '8', '1 tahun', '2017-06-26', '2017-06-30', 'Dream_Theater_-_Chaos_In_Motion_2007-2008.jpg', '<p>Akuntan public, jujur disiplin</p>\r\n', '07210-06246-032-01', 15000, 2),
(4, 'boss', 4, 4, 'Desain Grafis', 'Pria & Wanita', '30', '8', '1 tahun', '2017-06-26', '2017-07-11', '11048763_863740510361807_2179741323969777961_n.jpg', '<p>Desain grafis, ilustratrator</p>\r\n', '05476-03210-05-11', 15000, 2),
(5, 'boss', 6, 1, 'Pramuniaga', 'Wanita', '25', '8', '1 tahun', '2017-06-26', '2017-06-28', 'supra-x125-new-stripping.jpg', '<p>Pramunuiaga, penampilan menarik, baik, jujur, good looking</p>\r\n', '54710-04329-02-01', 25000, 2),
(6, 'boss', 11, 3, 'Kurir JNE', 'Pria', '30', '5', '-', '2017-06-26', '2017-06-27', 'header_1.png', '<p>Kurir punya sim c punya motor</p>\r\n', '15000', 25000, 1),
(7, 'boss', 3, 2, 'Manager Bengkel', 'Pria & Wanita', '30', '8', '1 tahun', '2017-06-28', '2017-07-21', '1936306_975179962529700_4244293917655576878_n.jpg', '<p>manager bengkel baik hati tidak sombong</p>\r\n', '07670-1901-02-20', 15000, 2),
(8, 'ajeng', 8, 2, 'Human Resource', 'Pria & Wanita', '30', '10', '2 tahun', '2017-07-12', '2017-07-23', 'Jagung-Benih-1.jpg', '<p>DICARI KARYAWAN BAIK HATI, MANUTAN DAN TIDAK IDEALIS</p>\r\n', '40929-9282-011-24', 25000, 1),
(9, 'spbutritis', 11, 2, 'Lowongan Operator', 'Pria & Wanita', 'max 25thn', '5', 'berrpengalaman ', '2017-07-24', '2017-07-30', 'IMG-20170724-WA0005.jpg', '<p>Lowongan Pekerjaan SPBU TITIS sebagai Operator</p>\r\n\r\n<p>Persyaratan:</p>\r\n\r\n<p>- Pria/Wanita</p>\r\n\r\n<p>- Usia max. 25thn, belum menikah</p>\r\n\r\n<p>- Pendidikan SMA/SMK Negeri</p>\r\n\r\n<p>- Nilai Matematika min 7.5</p>\r\n\r\n<p>- Tinggi minimal 160cm</p>\r\n\r\n<p>- Berat badan proposional</p>\r\n\r\n<p>- Penampilan menarik</p>\r\n\r\n<p>- Ramah, jujur, disiplin</p>\r\n\r\n<p>- Taat menjalankan agama</p>\r\n', '07930-2288159-330', 15000, 2),
(10, 'waroengnjowo', 11, 2, 'Lowongan Waitress', 'Pria', '18-26tahun', '5', 'berrpengalaman ', '2017-07-24', '2017-08-17', 'rm_waung_jowo.jpg', '<p>Lowongan Pekerjaan RM. Waroeng Njowo</p>\r\n\r\n<p>Dibutuhkan 2 Karyawan sebagai waitress</p>\r\n\r\n<p>Persyaratan:</p>\r\n\r\n<p>- Laki-laki</p>\r\n\r\n<p>- Usia 18-26 tahun</p>\r\n\r\n<p>- Pendidikan min SMA/SMK</p>\r\n\r\n<p>- Baligh/dewasa</p>\r\n\r\n<p>- Siap bekerja keras</p>\r\n\r\n<p>- Tidak terkait kontrak dengan perusahaan lain</p>\r\n\r\n<p>- Berkelakuan baik</p>\r\n', '05397-99819-241-11', 25000, 2),
(11, 'alfamartf', 11, 2, 'Lowongan Crew Of Store (CRW)', 'Pria & Wanita', 'usia 18 - 25thn', '5', 'berrpengalaman ', '2017-07-24', '2017-07-31', 'IMG-20170724-WA0006.jpg', '<p>Kesempatan Berkarir</p>\r\n\r\n<p>Lowongan posisi Crew Of Store (CRW)</p>\r\n\r\n<p>Kualifikasi:</p>\r\n\r\n<p>- Pria/Wanita</p>\r\n\r\n<p>- Belum Menikah</p>\r\n\r\n<p>- Usia Mak 25 tahun</p>\r\n\r\n<p>- Min SMA/SMK</p>\r\n\r\n<p>- Good looking &amp; Komunikatif</p>\r\n\r\n<p>- Memiliki E-KTP</p>\r\n', '06327-734179-09-11', 15000, 2),
(12, 'alfamartf', 11, 2, 'Lowongan Helper (HLP)', 'Pria', 'max 26thn', '5', 'berrpengalaman ', '2017-07-24', '2017-07-31', 'IMG-20170724-WA0006.jpg', '<p>Kesempatan Berkarir</p>\r\n\r\n<p>Lowongan posisi Helper (HLP)</p>\r\n\r\n<p>Kualifikasi:</p>\r\n\r\n<p>- Pria</p>\r\n\r\n<p>- Belum Menikah</p>\r\n\r\n<p>- Usia 18-26 tahun</p>\r\n\r\n<p>- Min SMA/SMK</p>\r\n\r\n<p>- Good looking &amp; Komunikatif</p>\r\n\r\n<p>- Memiliki E-KTP</p>\r\n', '0538-0389-2349-01-20', 15000, 2),
(13, 'alfamartf', 7, 2, 'Lowongan Sales Motoris (MRO)', 'Pria', 'usia 18 - 35thn', '5', 'berrpengalaman ', '2017-07-24', '2017-08-08', 'IMG-20170724-WA0006.jpg', '<p>Kesempatan Berkarir</p>\r\n\r\n<p>Lowongan posisi Sales Motoris (MRO)</p>\r\n\r\n<p>Kualifikasi:</p>\r\n\r\n<p>- Pria/Wanita</p>\r\n\r\n<p>- Belum Menikah</p>\r\n\r\n<p>- Usia 18-35 tahun</p>\r\n\r\n<p>- Min SMA/SMK</p>\r\n\r\n<p>- Good looking &amp; Komunikatif</p>\r\n\r\n<p>- Memiliki E-KTP</p>\r\n\r\n<p>Penempatan wilayah Cilacap</p>\r\n', '07844-792881-10-022', 25000, 2),
(14, 'alfamartf', 11, 2, 'Lowongan Store Leader Development (SLDP) ', 'Pria & Wanita', '18-27tahun', '11', 'fresh graduate ', '2017-07-24', '2017-08-17', 'IMG-20170724-WA0006.jpg', '<p>Kesempatan Berkarir</p>\r\n\r\n<p>Lowongan posisi Store Leader Development Program (SLDP)</p>\r\n\r\n<p>Kualifikasi:</p>\r\n\r\n<p>- Pria/Wanita</p>\r\n\r\n<p>- Belum Menikah</p>\r\n\r\n<p>- Usia 18-27 tahun</p>\r\n\r\n<p>- Min D3/S1 Semua jurusan</p>\r\n\r\n<p>- IPK min 2.75</p>\r\n\r\n<p>- Good looking &amp; Komunikatif</p>\r\n\r\n<p>- Memiliki E-KTP</p>\r\n\r\n<p>Penempatan wilayah Cilacap</p>\r\n', '527725-80210-2300-01', 25000, 2),
(15, 'automaxkry', 3, 2, 'Lowongan Mekanik', 'Pria', 'min 18 tahun', '4', 'smk otomotif', '2017-07-24', '2017-07-31', 'IMG-20170724-WA0007.jpg', '<p>Lowongan Pekerjaan</p>\r\n\r\n<p>Posisi:</p>\r\n\r\n<p>MEKANIK</p>\r\n\r\n<p>Syarat &ndash; syarat :</p>\r\n\r\n<ol>\r\n	<li>Pria</li>\r\n	<li>Lulusan min. SMK bidang Otomotif</li>\r\n	<li>Diutamakn memiliki kemampuan dibidang Otomotif (BERPENGALAMAN)</li>\r\n	<li>Disiplin, Jujur, Tekun</li>\r\n	<li>Mampu bekrja secara team</li>\r\n</ol>\r\n', '08721-054201-0689-10', 15000, 2),
(16, 'ajeng', 1, 1, 'Admin Olshop', 'Wanita', '23 tahun', '5', '1 tahun', '2017-07-26', '2017-07-31', '12006107_711873828947843_2830363256833696661_n.png', '<p>dicari admin olshop terbaik</p>\r\n', '', 0, 0),
(22, 'ajeng', 5, 2, 'Kurir Wahana', 'Pria', '27 tahun', '5', '1 tahun', '2017-08-10', '2017-08-17', '14494798_1195947227114993_2462564357510889687_n.jpg', '<p>tes pisah tb_pembayaran</p>\r\n', '', 0, 1),
(23, 'Hakim', 9, 2, 'Humas', 'Pria', '30', '11', '1 tahun', '2017-08-19', '2017-08-26', '11825924_10204181331965952_5131213669170976505_n.jpg', '<p>haha hehe hoho</p>\r\n', '', 0, 0),
(24, 'Hakim Luqman', 4, 2, 'Humas', 'Pria & Wanita', '30', '2', '3 tahun', '2017-08-22', '2017-08-31', '14705721_1860458944186385_1717973674416893213_n.jpg', '<p>qweqwe</p>\r\n', '', 0, 1),
(25, 'Hakim Luqman', 3, 2, 'sopir', 'Wanita', '27 tahun', '4', '2 tahun', '2017-08-22', '2017-08-31', '16825961_10206548282620846_8658584783643550155_o.jpg', '<p>SAFSF</p>\r\n', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_pelamar`
--

CREATE TABLE `tb_pelamar` (
  `id_pelamar` int(32) UNSIGNED NOT NULL,
  `user_id` char(15) NOT NULL,
  `nama_depan` varchar(30) NOT NULL,
  `nama_belakang` varchar(50) NOT NULL,
  `tempat_lahir` varchar(20) NOT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `jk` varchar(20) NOT NULL,
  `agama` char(15) NOT NULL,
  `provinsi` varchar(30) NOT NULL,
  `kota` varchar(30) NOT NULL,
  `alamat` mediumtext NOT NULL,
  `lulusan` varchar(30) NOT NULL,
  `usia` int(5) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `pengalaman` text NOT NULL,
  `tinggi_badan` int(15) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `kelebihan` text NOT NULL,
  `tgl_daftar` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_pelamar`
--

INSERT INTO `tb_pelamar` (`id_pelamar`, `user_id`, `nama_depan`, `nama_belakang`, `tempat_lahir`, `tgl_lahir`, `jk`, `agama`, `provinsi`, `kota`, `alamat`, `lulusan`, `usia`, `no_hp`, `pengalaman`, `tinggi_badan`, `foto`, `kelebihan`, `tgl_daftar`) VALUES
(15, 'puput', 'Puput', 'Puspito', 'Makasar', '0000-00-00', 'P', 'Islam', '', '', 'Jogja', 'SMA', 20, '08570291485', '10', 160, '1382322_999463726766849_7146171032535827511_n.jpg', '<p>BAIK HATI TIDAK SUKA MENCURI</p>\r\n', '2017-06-23 14:39:05'),
(16, 'luqman', 'Luqman', 'Hakim', 'Pati', '1993-07-01', 'P', 'Islam', '', '', 'Ngurenrejo', 'SMP', 20, '08570291485', '1 tahun', 160, '12798883_614392928713195_2021554980296622339_n.jpg', '<p>BAIK HATI</p>\r\n', '2017-08-23 12:23:10'),
(17, 'hakim', 'Luqman', 'Hakim', 'Pati', '2017-07-05', 'P', 'Islam', '', '', 'Ngurenrejo', 'SMA', 10, '08570291485', '1 tahun', 160, '13715986_262263680822809_8419129591439082064_n.jpg', '<p>jujur</p>\r\n', '2017-07-04 15:13:54'),
(18, 'lia', 'Lia', 'Lycious', 'Cilacap', '1996-06-06', 'Wanita', 'Islam', '', '', 'Jogja', 'SMA', 20, '08570291485', '1 tahun', 160, 'tepung-beras.jpg', '<p>HJASDJKS</p>\r\n', '2017-07-11 12:29:54'),
(19, 'riski', 'Riski', 'Ana', 'Purbalingga', '1994-07-14', 'Wanita', 'Islam', '', '', 'Purbalingga', 'SMA', 20, '0897426319409', '1 tahun', 162, 'indomie-rasa-kari-ayam-dengan-bawang-goreng_big.png', '<p>SUKA NGOPI</p>\r\n', '2017-07-12 15:00:14'),
(20, 'muzan', 'Muhammad', 'Muzan R', 'Banyumas', '1995-07-24', 'Pria', 'islam', '', '', 'jalan s parman purwokerto banyumas jawa tengah', 'S1', 22, '085700013161', 'fresh graduate', 170, 'IMG_8251.jpg', '<p>menguasai ms.word, ms.excel, php, javascript</p>\r\n', '2017-07-24 04:17:40'),
(21, 'amal', '', '', '', NULL, '', '', '', '', '', '', 0, '', '', 0, '', '', '2017-07-25 10:33:51'),
(22, 'dream', 'Haha', 'hehe', 'huhu', '2006-08-10', 'Pria', 'Islam', '2', '9', 'jogja', 'SMP', 10, '08570291485', '1 tahun', 30, '', '<p>sads</p>\r\n', '2017-08-23 15:17:51'),
(23, 'Hakim', '', '', '', NULL, '', '', '', '', '', '', 0, '', '', 0, '', '', '2017-08-19 14:46:26'),
(24, 'Hakim', '', '', '', NULL, '', '', '', '', '', '', 0, '', '', 0, '', '', '2017-08-19 15:01:21');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pembayaran`
--

CREATE TABLE `tb_pembayaran` (
  `id` int(11) NOT NULL,
  `id_lowongan` int(11) NOT NULL,
  `transfer` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_pembayaran`
--

INSERT INTO `tb_pembayaran` (`id`, `id_lowongan`, `transfer`) VALUES
(1, 22, '14650321_10205536857540546_4678672224832703903_n.jpg'),
(4, 24, '16999128_1259010604179883_3119883251875259392_n.jpg'),
(5, 25, '10613011_766630883378828_7479412313690021737_n.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tb_perusahaan`
--

CREATE TABLE `tb_perusahaan` (
  `id_perusahaan` int(10) UNSIGNED NOT NULL,
  `user_id` char(15) NOT NULL,
  `nama_perusahaan` varchar(100) NOT NULL,
  `alamat` text NOT NULL,
  `kota` varchar(45) NOT NULL,
  `prov` varchar(45) NOT NULL,
  `no_telp` varchar(15) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `ket_perusahaan` text NOT NULL,
  `tgl_daftar` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_perusahaan`
--

INSERT INTO `tb_perusahaan` (`id_perusahaan`, `user_id`, `nama_perusahaan`, `alamat`, `kota`, `prov`, `no_telp`, `logo`, `ket_perusahaan`, `tgl_daftar`) VALUES
(1, 'topan', 'PT. Makmur Sentosa', 'Jombor', 'Jogja', 'Daerah Istimewa Yogyakarta', '087624567527', 'Undangan_BKD.png', '<p>PT. Makmur Sentosa adalah perusahaan yang bergerak di bidang jasa</p>\r\n', '2017-06-26 15:09:26'),
(2, 'boss', 'CV. Solusi Mandiri', 'Jl. Glagahsari', 'Cilacap', 'Jawa Tengah', '089747219233', '1382322_999463726766849_7146171032535827511_n.jpg', '<p>CV. Solusi Mandiri adalah startup yang berdiri pada tahun 2015, merupakan perusahaan di bidang industri kreative</p>\r\n', '2017-07-01 03:45:18'),
(3, 'ajeng', 'Fashion Trendi', 'Cilacap', 'Cilacap', 'Jawa Tengah', '089747219233', 'cabai-keriting.jpg', '<p>bergerak di bidang fashion</p>\r\n', '2017-07-12 14:44:19'),
(4, 'spbutritis', 'PT. Pertamina (SPBU TITIS)', 'Jl. Yos Sudarso No.3 Karangmangu Kroya', 'Cilacap', 'Jawa Tengah', '085264298960', 'pertamina.jpg', '<p>Pertamina merupakan perusahaan milik negara yang bergerak di bidang energi meliputi minyak, gas serta energi baru dan terbarukan.Pertamina menjalankan kegiatan bisnisnya berdasarkan prinsip-prinsip tata kelola korporasi yang baik sehingga dapat berdaya saing yang tinggi di dalam era globalisasi.</p>\r\n\r\n<p>Dengan pengalaman lebih dari 56 tahun, Pertamina semakin percaya diri untuk berkomitmen menjalankan kegiatan bisnisnya secara profesional dan penguasaan teknis yang tinggi mulai dari kegiatan hulu sampai hilir.Berorientasi pada kepentingan pelanggan juga merupakan suatu hal yang menjadi komitmen Pertamina,agar dapat berperan dalam memberikan nilai tambah bagi kemajuan dan kesejahteraan bangsa Indonesia.</p>\r\n\r\n<p><br />\r\nUpaya perbaikan dan inovasi sesuai tuntutan kondisi global merupakan salah satu komitmen Pertamina dalam setiap kiprahnya menjalankan peran strategis dalam perekonomian nasional. Semangat terbarukan yang dicanangkan saat ini merupakan salah satu bukti komitmen Pertamina dalam menciptakan alternatif baru dalam penyediaan sumber energi yang lebih efisien dan berkelanjutan serta berwawasan lingkungan. Dengan inisatif dalam memanfaatkan sumber daya dan potensi yang dimiliki untuk mendapatkan sumber energi baru dan terbarukan di samping bisnis utama yang saat ini dijalankannya, Pertamina bergerak maju dengan mantap untuk mewujudkan visi perusahaan, Menjadi Perusahaan Energi Nasional Kelas Dunia.</p>\r\n\r\n<p><br />\r\nMendukung visi tersebut, Pertamina menetapkan strategi jangka panjang perusahaan, yaitu &ldquo;Aggressive in Upstream, Profitable in Downstream&rdquo;, dimana Perusahaan berupaya untuk melakukan ekspansi bisnis hulu dan menjadikan bisnis sektor hilir migas menjadi lebih efisien dan menguntungkan.</p>\r\n', '2017-07-24 02:51:43'),
(5, 'waroengnjowo', 'Rumah Makan Waroeng Njowo', 'jl. jendral sudirman rt17/rw4 kroya', 'Cilacap', 'Jawa Tengah', '082325655094', 'rm_waung_jowo.jpg', '<p>RM. Waroeng Njowo merupakan usaha perseorangan dibidang kuliner yang berada di Cilacap. Rumah Makan Waroeng Njowo yaitu restoran berkonsep kehangatan keluarga dengan nuansa jawa berupa saung dan joglo.</p>\r\n\r\n<p>Lokasi RM Waoeng Njowo sangat setrategis berada di samping alun alun tugu.</p>\r\n', '2017-07-24 03:59:29'),
(6, 'alfamartf', 'PT. Sumber Alfaria Trijaya Tbk,.', 'jl. jendral sudirman no. 5 kroya', 'Cilacap', 'Jawa Tengah', '085264298960', 'logo_alfamart.jpg', '<p>PT. Sumber Alfaria Trijaya Tbk,. perusahaan retail minimarket terkemuka di Indonesia pemegang lisensi merk dagang Alfamart yang tergabung dalam Alfagroup (Alfamart, Alfamidi, Lawson, dan lainnya).</p>\r\n', '2017-07-24 04:45:37'),
(7, 'automaxkry', 'Automax Automative Center', 'jl. A Yani No.1 Kedawung kroya', 'Cilacap', 'Jawa Tengah', '0282492222', 'IMG-20170724-WA0007.jpg', '<p>Automax Automative Center merupakan perusahaan bergerak dibidang otomotif, penjualan suku cadang/onderdil, variasi mobil, dan carwash yang merupakan perusahaan perseorangan dan tidak memiliki cabang</p>\r\n', '2017-07-24 05:12:52'),
(8, 'celeng', '', '', '', '', '', '', '', '2017-07-30 07:29:20'),
(9, 'theater', '', '', '', '', '', '', '', '2017-07-30 07:30:28'),
(10, 'Hakim', 'Makmur Jaya Sentosa', 'Pati', '', '', '08988122295', '12744650_805655719563075_1673764771504229962_n.jpg', '<p>eh</p>\r\n', '2017-08-19 15:16:57'),
(11, 'Hakim', 'Makmur Jaya Sentosa', 'Pati', '', '', '08988122295', '12744650_805655719563075_1673764771504229962_n.jpg', '<p>eh</p>\r\n', '2017-08-19 15:16:57'),
(12, 'Hakim', 'Makmur Jaya Sentosa', 'Pati', '', '', '08988122295', '12744650_805655719563075_1673764771504229962_n.jpg', '<p>eh</p>\r\n', '2017-08-19 15:16:57'),
(13, 'Hakim Luqman', 'Makmur Terus', 'JOgja', '', '', '0897337', 'C_R6X8IUMAI-LZc.jpg:large.jpeg', '<p>hsjdhjs</p>\r\n', '2017-08-22 00:04:16');

-- --------------------------------------------------------

--
-- Table structure for table `tb_provinsi`
--

CREATE TABLE `tb_provinsi` (
  `id_provinsi` tinyint(2) NOT NULL,
  `provinsi` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_provinsi`
--

INSERT INTO `tb_provinsi` (`id_provinsi`, `provinsi`) VALUES
(1, 'Jawa Tengah'),
(2, 'Yogyakarta');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id` int(11) NOT NULL COMMENT 'ID User',
  `user_id` char(15) NOT NULL,
  `uname` varchar(32) NOT NULL COMMENT 'Username',
  `upsw` varchar(40) NOT NULL COMMENT 'Password',
  `email` varchar(30) NOT NULL,
  `uac` char(20) NOT NULL COMMENT 'Tipe',
  `active` tinyint(1) NOT NULL COMMENT 'Status'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id`, `user_id`, `uname`, `upsw`, `email`, `uac`, `active`) VALUES
(1, 'admin', 'admin', '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8', 'admin.loker@gmail.com', 'ADM', 1),
(2, '', 'pelamar', '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8', '', 'PELAMAR', 1),
(3, '', 'perusahaan', '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8', '', 'PERUSAHAAN', 1),
(4, 'tarjo', 'tarjo', '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8', 'tar', 'PELAMAR', 0),
(5, 'nur', 'nur', '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8', 'nur', 'PELAMAR', 0),
(6, 'topan', 'topan', '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8', 'topan@gmail.com', 'PERUSAHAAN', 0),
(7, 'bos', 'bos', '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8', 'bos', 'PELAMAR', 0),
(8, 'boss', 'boss', '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8', 'boss@gmail.com', 'PERUSAHAAN', 0),
(9, 'candra', 'candra', '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8', 'candra@gmail.com', 'PELAMAR', 0),
(10, 'puput', 'puput', '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8', 'puput@gmail.com', 'PELAMAR', 0),
(11, 'luqman', 'luqman', '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8', 'luqman@gmail.com', 'PELAMAR', 0),
(13, 'lia', 'lia', '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8', 'lia@gmail.com', 'PELAMAR', 0),
(14, 'ajeng', 'ajeng', 'e9d71f5ee7c92d6dc9e92ffdad17b8bd49418f98', 'ajeng@gmail.com', 'PERUSAHAAN', 0),
(15, 'riski', 'riski', '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8', 'riski@gmail.com', 'PELAMAR', 0),
(16, 'spbutritis', 'spbutritis', '4fcc197324256345cbdee440725e3fbbf0fec024', 'amaliyanasithotul@gmail.com', 'PERUSAHAAN', 0),
(17, 'waroengnjowo', 'waroengnjowo', '5822b1bdab18c6584f48b78af76a8132a43f7b3f', 'endahayu18@gmail.com', 'PERUSAHAAN', 0),
(18, 'muzan', 'muzan', 'baab49d2ae54fe4dfc159030a3b553628833fc47', 'muhammadmuzan@gmail.com', 'PELAMAR', 0),
(19, 'alfamartf', 'alfamartf', '241fb464ea97588a8b32110c236a896c426e239a', 'satkroya2cilacap.clc@store.st.', 'PERUSAHAAN', 0),
(20, 'automaxkry', 'automaxkry', '7713f26e28bd4e09bee8ad11dd93327fd177a982', 'automax.kroya@gmail.com', 'PERUSAHAAN', 0),
(21, 'amal', 'amal', '7a671c37cb54c6697b951e2d1519f2d53de2e78f', 'amaliya17@gmail.com', 'PELAMAR', 0),
(22, 'dream', 'dream', '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8', 'dream@gmail.com', 'PELAMAR', 0),
(23, 'celeng', 'celeng', '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8', 'celeng@gmail.com', 'PERUSAHAAN', 0),
(24, 'theater', 'theater', '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8', 'theater@gmail.com', 'PERUSAHAAN', 0),
(30, 'Hakim Luqman', 'Hakim Luqman', 'heckem93', 'luckman.heckem@gmail.com', 'PERUSAHAAN', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_jenis_pekerjaan`
--
ALTER TABLE `tb_jenis_pekerjaan`
  ADD PRIMARY KEY (`id_jenis`);

--
-- Indexes for table `tb_kategori_pekerjaan`
--
ALTER TABLE `tb_kategori_pekerjaan`
  ADD PRIMARY KEY (`id_kategori_kerja`);

--
-- Indexes for table `tb_kategori_pendidikan`
--
ALTER TABLE `tb_kategori_pendidikan`
  ADD PRIMARY KEY (`id_pendidikan`);

--
-- Indexes for table `tb_kota`
--
ALTER TABLE `tb_kota`
  ADD PRIMARY KEY (`id_kota`);

--
-- Indexes for table `tb_lamaran`
--
ALTER TABLE `tb_lamaran`
  ADD PRIMARY KEY (`id_lamaran`),
  ADD KEY `id_lowongan` (`id_lowongan`),
  ADD KEY `id_pelamar` (`user_id`),
  ADD KEY `id_lowongan_2` (`id_lowongan`);

--
-- Indexes for table `tb_lowongan`
--
ALTER TABLE `tb_lowongan`
  ADD PRIMARY KEY (`id_lowongan`),
  ADD KEY `id_perusahaan` (`user_id`),
  ADD KEY `id_kategori_pekerjaan` (`id_kategori_pekerjaan`),
  ADD KEY `id_kategori_pekerjaan_2` (`id_kategori_pekerjaan`),
  ADD KEY `id_jenis` (`id_jenis`),
  ADD KEY `id_pendidikan` (`id_pendidikan`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `id_kategori_pekerjaan_3` (`id_kategori_pekerjaan`);

--
-- Indexes for table `tb_pelamar`
--
ALTER TABLE `tb_pelamar`
  ADD PRIMARY KEY (`id_pelamar`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tb_pembayaran`
--
ALTER TABLE `tb_pembayaran`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_lowongan` (`id_lowongan`);

--
-- Indexes for table `tb_perusahaan`
--
ALTER TABLE `tb_perusahaan`
  ADD PRIMARY KEY (`id_perusahaan`);

--
-- Indexes for table `tb_provinsi`
--
ALTER TABLE `tb_provinsi`
  ADD PRIMARY KEY (`id_provinsi`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_jenis_pekerjaan`
--
ALTER TABLE `tb_jenis_pekerjaan`
  MODIFY `id_jenis` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tb_kategori_pekerjaan`
--
ALTER TABLE `tb_kategori_pekerjaan`
  MODIFY `id_kategori_kerja` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tb_kategori_pendidikan`
--
ALTER TABLE `tb_kategori_pendidikan`
  MODIFY `id_pendidikan` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `tb_kota`
--
ALTER TABLE `tb_kota`
  MODIFY `id_kota` smallint(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `tb_lamaran`
--
ALTER TABLE `tb_lamaran`
  MODIFY `id_lamaran` smallint(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tb_lowongan`
--
ALTER TABLE `tb_lowongan`
  MODIFY `id_lowongan` smallint(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `tb_pelamar`
--
ALTER TABLE `tb_pelamar`
  MODIFY `id_pelamar` int(32) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `tb_pembayaran`
--
ALTER TABLE `tb_pembayaran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tb_perusahaan`
--
ALTER TABLE `tb_perusahaan`
  MODIFY `id_perusahaan` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `tb_provinsi`
--
ALTER TABLE `tb_provinsi`
  MODIFY `id_provinsi` tinyint(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID User', AUTO_INCREMENT=31;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
